package local.hal.st31.android.skseller;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import java.util.HashMap;
import java.util.Map;

public class PublicDialogFragment extends DialogFragment {
    /**
     * input項目郡フィールド。
     */
    Map<String, String> _keys = new HashMap<>();
    /**
     * post先のURL。
     */
    private static String POST_URL;

    /**
     * コンストラクタ。
     */
    public PublicDialogFragment(String url, String id){
        POST_URL = url;
        _keys.put("id", id);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(R.string.public_dlg_msg);
        builder.setPositiveButton(R.string.public_dlg_btn_ok, new DialogButtonClickListener());
        builder.setNegativeButton(R.string.public_dlg_btn_ng, new DialogButtonClickListener());
        AlertDialog dialog = builder.create();
        return dialog;
    }

    /**
     * ダイアログボタンが押された時の処理が記述されたメンバクラス。
     */
    private class DialogButtonClickListener implements DialogInterface.OnClickListener{
        @Override
        public void onClick(DialogInterface dialog, int which){
            Activity parent = getActivity();
            switch (which){
                case DialogInterface.BUTTON_POSITIVE:
                    // サーバーに送信
                    PostTransfer post = new PostTransfer();
                    if(post.sendPostDate(POST_URL, _keys)){
                        Toast.makeText(parent, R.string.public_toast_ok, Toast.LENGTH_SHORT).show();
                        // 画面遷移
                        Intent intent = new Intent(parent, MainActivity.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(parent, R.string.public_toast_ng, Toast.LENGTH_SHORT).show();
                    }
                    break;
                case DialogInterface.BUTTON_NEGATIVE:
                    // しょりなし
                    break;
            }
        }
    }
}
