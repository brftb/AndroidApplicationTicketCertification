package local.hal.st31.android.skseller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    /**
     * get先のURL。
     */
    private String ACCESS_URL = "";
    /**
     * リストビュー。
     */
    private ListView _lvEventsList;
    /**
     * リストビューに表示させるリストデータ。
     */
    private List<Map<String, String>> _list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // set url
        ACCESS_URL = getResources().getString(R.string.api_url) + "event/list";

        // リストset
        _lvEventsList = findViewById(R.id.lvEventsList);
        _lvEventsList.setOnItemClickListener(new ListItemClickListener());
    }

    @Override
    protected void onResume(){
        super.onResume();
        // リストの取得・表示
        String[] from = {"E_name"};
        int[] to = {android.R.id.text1, android.R.id.text2};
        GetTransfer get = new GetTransfer();
        String[] keys = {"E_id", "E_name"};
        _list = get.receiveList(ACCESS_URL, keys);
        SimpleAdapter adapter = new SimpleAdapter(MainActivity.this, _list, android.R.layout.simple_list_item_1, from, to);
        _lvEventsList.setAdapter(adapter);
    }

    /**
     * リストがタップされた時の処理が記述されたリスナクラス。
     */
    private class ListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            // チケット詳細画面へ処理を移管する。
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            intent.putExtra("idNo", _list.get(position).get("E_id"));
            startActivity(intent);
        }
    }

    /**
     * アクションバーの設置
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_options_activity_main, menu);
        return true;
    }

    /**
     * アクションバーが押された時の処理。
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int itemId = item.getItemId();
        if (itemId == R.id.menuMainAdd){
            // 第２画面へ処理を移管する。
            Intent intent = new Intent(MainActivity.this, AddActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}