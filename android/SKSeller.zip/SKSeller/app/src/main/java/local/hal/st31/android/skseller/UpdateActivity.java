package local.hal.st31.android.skseller;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import java.util.Calendar;
import java.util.Objects;

public class UpdateActivity extends AppCompatActivity {
    /**
     * 現在表示している情報のデータベース上の主キー値。
     */
    private String _idNo;
    /**
     * 現在表示している情報。
     */
    private String _eventName;
    private String _eventDatetime;
    private String _eventTicketSum;
    private String _eventDescription;
    /**
     * 日時の値(update用の形式)。
     */
    private String _inputDate;
    private String _inputTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        Intent intent = getIntent();
        _idNo = intent.getStringExtra("idNo");
        // 前画面から情報を取得
        _eventName = intent.getStringExtra("E_name");
        _eventDatetime = intent.getStringExtra("E_datetime");
        _eventTicketSum = intent.getStringExtra("E_ticket_sum");
        _eventDescription = intent.getStringExtra("E_description");

        // アクションバーに前画面に戻る機能をつける
        ActionBar actionBar = getSupportActionBar();
        Objects.requireNonNull(actionBar).setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 初期値の取得・表示
        ((EditText)findViewById(R.id.etInputName)).setText(_eventName);
        ((EditText)findViewById(R.id.etInputDate)).setText(_eventDatetime.substring(0,11));
        ((EditText)findViewById(R.id.etInputTime)).setText(_eventDatetime.substring(12,18));
        ((TextView)findViewById(R.id.etInputNum)).setText(_eventTicketSum);
        ((TextView)findViewById(R.id.etInputDescription)).setText(_eventDescription);
        // 日時の型変換
        String year = _eventDatetime.substring(0,4);
        String month = _eventDatetime.substring(5,7);
        String day = _eventDatetime.substring(8,10);
        String hour = _eventDatetime.substring(12,14);
        String minute = _eventDatetime.substring(15,17);
        _inputDate = year+"-"+month+"-"+day;
        _inputTime = hour+":"+minute+":00";
    }

    /**
     * 登録内容確認ボタンがクリックされたときの処理メソッド。
     *
     * @param view Viewオブジェクト。
     */
    public void onUpdateButtonClick(View view){
        // 入力情報の取得
        EditText etInputName = findViewById(R.id.etInputName);
        String inputName = etInputName.getText().toString();
//        String inputDatetime = ((EditText)findViewById(R.id.etInputDatetime)).getText().toString();
        String inputNum = ((EditText)findViewById(R.id.etInputNum)).getText().toString();
        String inputDescription = ((EditText)findViewById(R.id.etInputDescription)).getText().toString();
        // 必須入力の確認
        if (inputName.equals("")) {
            Toast.makeText(UpdateActivity.this, R.string.msg_input_name, Toast.LENGTH_SHORT).show();
        }else if (inputNum.equals("")) {
            Toast.makeText(UpdateActivity.this, R.string.msg_input_num, Toast.LENGTH_SHORT).show();
        } else {
            // 登録のダイアログ表示
            String urlUpdate = getString(R.string.api_url) + "event/update";
            UpdateDialogFragment dialog = new UpdateDialogFragment(urlUpdate, _idNo, inputName, _inputDate+" "+_inputTime, inputNum, inputDescription);
            FragmentManager manager = getSupportFragmentManager();
            dialog.show(manager, "UpdateDialogFragment");
        }
    }

    /**
     * InputDateがクリックされたときの処理メソッド。
     * @param view Viewオブジェクト。
     */
    public void onInputDateClick(View view){
        // 初期値は現在日付
        Calendar cal = Calendar.getInstance();
        int nowYear = cal.get(Calendar.YEAR);
        int nowMonth = cal.get(Calendar.MONTH);
        int nowDayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        // dialog
        DatePickerDialog dialog = new DatePickerDialog(UpdateActivity.this, new DatePickerDialogTimeSetListener(), nowYear, nowMonth, nowDayOfMonth);
        dialog.show();
    }
    /**
     * InputTimeがクリックされたときの処理メソッド。
     * @param view Viewオブジェクト。
     */
    public void onInputTimeClick(View view){
        // dialog
        TimePickerDialog dialog = new TimePickerDialog(UpdateActivity.this, new TimePickerDialogTimeSetListener(), 0, 0, true);
        dialog.show();
    }

    /**
     * 日付選択ダイアログの完了ボタンが押された時の処理が記述されたメンバクラス。
     */
    private class DatePickerDialogTimeSetListener implements DatePickerDialog.OnDateSetListener{
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth){
            String msg = year + "年" + (month+1) + "月" + dayOfMonth + "日";
            // 表示
            ((EditText)findViewById(R.id.etInputDate)).setText(msg);
            // フィールドに格納
            _inputDate = year + "-" + (month+1) + "-" + dayOfMonth;
        }
    }

    /**
     * 時間選択ダイアログの完了ボタンが押された時の処理が記述されたメンバクラス。
     */
    private class TimePickerDialogTimeSetListener implements TimePickerDialog.OnTimeSetListener{
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute){
            String msg = hourOfDay + "時" + minute + "分";
            // 表示
            ((EditText)findViewById(R.id.etInputTime)).setText(msg);
            // フィールドに格納
            _inputTime = hourOfDay + ":" + minute + ":00";
        }
    }

    /**
     * アクションバーの設置
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_options_activity_update, menu);
        return true;
    }

    /**
     * アクションバーが押された時の処理。
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int itemId = item.getItemId();
        switch (itemId) {
            case R.id.menuDelete:
                // 削除ダイアログ表示
                String urlDelete = getString(R.string.api_url) + "event/delete";
                DeleteDialogFragment dialog = new DeleteDialogFragment(urlDelete, _idNo);
                FragmentManager manager = getSupportFragmentManager();
                dialog.show(manager, "DeleteDialogFragment");
                break;
            case android.R.id.home:
                finish(); // 画面終了(イベント詳細画面に戻る)
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}
