package local.hal.st31.android.skseller;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import java.util.HashMap;
import java.util.Map;

public class UpdateDialogFragment extends DialogFragment {
    /**
     * input項目郡フィールド。
     */
    Map<String, String> _keys = new HashMap<>();
    /**
     * post先のURL。
     */
    private static String POST_URL;

    /**
     * コンストラクタ。
     */
    public UpdateDialogFragment(String url, String id, String name, String datetime, String sum, String description){
        POST_URL = url;
        _keys.put("id", id);
        _keys.put("name", name);
        _keys.put("datetime", datetime);
        _keys.put("sum", sum);
        _keys.put("description", description);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.update_dlg_title);
        String message = getString(R.string.update_dlg_msg);
        message += "\n" + "イベント名：" + _keys.get("name");
        message += "\n" + "日付：" + _keys.get("datetime");
        message += "\n" + "チケット総数：" + _keys.get("sum");
        builder.setMessage(message);
        builder.setPositiveButton(R.string.update_dlg_btn_ok, new DialogButtonClickListener());
        builder.setNegativeButton(R.string.update_dlg_btn_ng, new DialogButtonClickListener());
        AlertDialog dialog = builder.create();
        return dialog;
    }

    /**
     * ダイアログボタンが押された時の処理が記述されたメンバクラス。
     */
    private class DialogButtonClickListener implements DialogInterface.OnClickListener{
        @Override
        public void onClick(DialogInterface dialog, int which){
            Activity parent = getActivity();
            switch (which){
                case DialogInterface.BUTTON_POSITIVE:
                    // サーバーに送信
                    PostTransfer post = new PostTransfer();
                    if(post.sendPostDate(POST_URL, _keys)){
                        Toast.makeText(parent, R.string.update_toast_ok, Toast.LENGTH_SHORT).show();
                        // 画面遷移
                        Intent intent = new Intent(parent, MainActivity.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(parent, R.string.update_toast_ng, Toast.LENGTH_SHORT).show();
                    }
                    break;
                case DialogInterface.BUTTON_NEGATIVE:
                    // しょりなし
                    break;
            }
        }
    }
}
