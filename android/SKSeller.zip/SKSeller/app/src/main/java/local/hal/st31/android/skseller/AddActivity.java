package local.hal.st31.android.skseller;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import java.util.Calendar;
import java.util.Objects;

public class AddActivity extends AppCompatActivity {
    /**
     * 現在表示している日時の値(insert用の形式)。
     */
    private String _inputDate;
    private String _inputTime;
    /**
     * post先のURL。
     */
    private static String POST_URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // set url
        POST_URL = getResources().getString(R.string.api_url) + "event/register";

        // アクションバーに前画面に戻る機能をつける
        ActionBar actionBar = getSupportActionBar();
        Objects.requireNonNull(actionBar).setDisplayHomeAsUpEnabled(true);
    }

    /**
     * 登録内容確認ボタンがクリックされたときの処理メソッド。
     *
     * @param view Viewオブジェクト。
     */
    public void onAddButtonClick(View view){
        // 入力情報の取得
        EditText etInputName = findViewById(R.id.etInputName);
        String inputName = etInputName.getText().toString();
        String inputDate = ((EditText)findViewById(R.id.etInputDate)).getText().toString();
        String inputTime = ((EditText)findViewById(R.id.etInputTime)).getText().toString();
        String inputSum = ((EditText)findViewById(R.id.etInputNum)).getText().toString();
        String inputDescription = ((EditText)findViewById(R.id.etInputDescription)).getText().toString();
        // 必須入力の確認
        if (inputName.equals("")) {
            Toast.makeText(AddActivity.this, R.string.msg_input_name, Toast.LENGTH_SHORT).show();
        }else if (inputDate.equals("") || inputTime.equals("")) {
            Toast.makeText(AddActivity.this, R.string.msg_input_datetime, Toast.LENGTH_SHORT).show();
        }else if (inputSum.equals("")) {
            Toast.makeText(AddActivity.this, R.string.msg_input_num, Toast.LENGTH_SHORT).show();
        } else {
            // 登録のダイアログ表示
            RegisterDialogFragment dialog = new RegisterDialogFragment(POST_URL, inputName, _inputDate+" "+_inputTime, inputSum, inputDescription);
            FragmentManager manager = getSupportFragmentManager();
            dialog.show(manager, "RegisterDialogFragment");
        }
    }

    /**
     * InputDateがクリックされたときの処理メソッド。
     * @param view Viewオブジェクト。
     */
    public void onInputDateClick(View view){
        // 初期値は現在日付
        Calendar cal = Calendar.getInstance();
        int nowYear = cal.get(Calendar.YEAR);
        int nowMonth = cal.get(Calendar.MONTH);
        int nowDayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        // dialog
        DatePickerDialog dialog = new DatePickerDialog(AddActivity.this, new DatePickerDialogTimeSetListener(), nowYear, nowMonth, nowDayOfMonth);
        dialog.show();
    }
    /**
     * InputTimeがクリックされたときの処理メソッド。
     * @param view Viewオブジェクト。
     */
    public void onInputTimeClick(View view){
        // dialog
        TimePickerDialog dialog = new TimePickerDialog(AddActivity.this, new TimePickerDialogTimeSetListener(), 0, 0, true);
        dialog.show();
    }

    /**
     * 日付選択ダイアログの完了ボタンが押された時の処理が記述されたメンバクラス。
     */
    private class DatePickerDialogTimeSetListener implements DatePickerDialog.OnDateSetListener{
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth){
            String msg = year + "年" + (month+1) + "月" + dayOfMonth + "日";
            // 表示
            ((EditText)findViewById(R.id.etInputDate)).setText(msg);
            // フィールドに格納
            _inputDate = year + "-" + (month+1) + "-" + dayOfMonth;
        }
    }

    /**
     * 時間選択ダイアログの完了ボタンが押された時の処理が記述されたメンバクラス。
     */
    private class TimePickerDialogTimeSetListener implements TimePickerDialog.OnTimeSetListener{
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute){
            String msg = hourOfDay + "時" + minute + "分";
            // 表示
            ((EditText)findViewById(R.id.etInputTime)).setText(msg);
            // フィールドに格納
            _inputTime = hourOfDay + ":" + minute + ":00";
        }
    }

    /**
     * アクションバーが押された時の処理。
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int itemId = item.getItemId();
        switch (itemId) {
            case android.R.id.home:
                finish(); // 画面終了(イベント一覧画面に戻る)
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}
