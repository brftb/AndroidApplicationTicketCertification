package local.hal.st31.android.skseller;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class QRScannerActivity extends AppCompatActivity {
    /**
     * 現在表示している情報のデータベース上の主キー値。
     */
    private String _idNo;
    /**
     * post先のURL。
     */
    private static String POST_URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_scanner);

        // set url
        POST_URL = getResources().getString(R.string.api_url) + "qr/scan";

        // eventIdを取得
        Intent intent = getIntent();
        _idNo = intent.getStringExtra("event_id");

        // アクションバーに前画面に戻る機能をつける
        ActionBar actionBar = getSupportActionBar();
        Objects.requireNonNull(actionBar).setDisplayHomeAsUpEnabled(true);
    }

    // QRコードリーダーを起動する
    public void scanQrCode() {
        new IntentIntegrator(this)
                .setOrientationLocked(false)
                .setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
                .setCaptureActivity(MyCaptureActivity.class)
                .setPrompt(getString(R.string.prompt_msg))
                .initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // QRコードを読み込んだ後の処理
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null && result.getContents() != null) {
            // QRコードのデータを取得する
            String strResult = result.getContents();

            // 認証
            PostTransfer postTransfer = new PostTransfer();
            Map<String,String> key = new HashMap<>();
            key.put("code", strResult);
            key.put("eventId", _idNo);
            String strStatus = postTransfer.sendPostDateToGetResult(POST_URL, key);
            if(strStatus.equals("expired")){
                TextView tvScanner = findViewById(R.id.tvScanner);
                tvScanner.setText(getString(R.string.scan_msg_expired));
            }else if(strStatus.equals("ok")){
                ((TextView)findViewById(R.id.tvScanner)).setText(getString(R.string.scan_msg_ok));
            }else if(strStatus.equals("err")){
                ((TextView)findViewById(R.id.tvScanner)).setText(getString(R.string.scan_msg_err));
            }else if(strStatus.equals("ng")){
                ((TextView)findViewById(R.id.tvScanner)).setText(getString(R.string.scan_msg_ng));
            }


        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }


    /**
     * ボタンがクリックされたときの処理メソッド。
     *
     * @param view Viewオブジェクト。
     */
    public void onStartScannerButtonClick(View view){
        scanQrCode();
    }

    /**
     * アクションバーが押された時の処理。
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int itemId = item.getItemId();
        switch (itemId) {
            case android.R.id.home:
                finish(); // 画面終了(mypage画面に戻る)
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}
