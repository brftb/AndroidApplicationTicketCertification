package local.hal.st31.android.skseller;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import java.util.Map;
import java.util.Objects;

public class DetailActivity extends AppCompatActivity {
    /**
     * 現在表示している情報のデータベース上の主キー値。
     */
    private String _idNo;
    /**
     * get先のURL。
     */
    private static String GET_URL;
    /**
     * 現在表示している情報。
     */
    private Map<String, String> _event;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // set url
        GET_URL = getString(R.string.api_url) + "event/detail";

        // eventIdを取得
        Intent intent = getIntent();
        _idNo = intent.getStringExtra("idNo");

        // アクションバーに前画面に戻る機能をつける
        ActionBar actionBar = getSupportActionBar();
        Objects.requireNonNull(actionBar).setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected void onResume(){
        super.onResume();
        // 送信パラメータと受信パラメータのセット
        String urlFull = GET_URL + "?event_id=" + _idNo;
        String[] keys = {"E_name", "E_datetime", "E_ticket_sum", "E_description", "E_public_flag"};
        // 初期値の取得・表示
        GetTransfer getTransfer = new GetTransfer();
        _event = getTransfer.receiveMap(urlFull, "eventDetail", keys);
        ((TextView)findViewById(R.id.etInputName)).setText(_event.get("E_name"));
        ((TextView)findViewById(R.id.etInputDatetime)).setText(_event.get("E_datetime"));
        ((TextView)findViewById(R.id.etInputNum)).setText(_event.get("E_ticket_sum"));
        ((TextView)findViewById(R.id.etInputDescription)).setText(_event.get("E_description"));

        // 非公開の場合ボタンを非活性
        if(_event.get("E_public_flag").equals("0")){
            Button btnScanner = findViewById(R.id.btnScanner);
            btnScanner.setText(R.string.btn_detail_disabled);
            btnScanner.setEnabled(false);
        }
    }

    /**
     * スキャナーボタンがクリックされた時の処理。
     * @param view 画面部品。
     */
    public void onScannerButtonClick(View view){
        // スキャン画面へ処理を移管する。
        Intent intent = new Intent(DetailActivity.this, QRScannerActivity.class);
        intent.putExtra("event_id", _idNo);
        startActivity(intent);
    }

    /**
     * アクションバーの設置
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        if(_event.get("E_public_flag").equals("0")) {
            inflater.inflate(R.menu.menu_options_activity_detail, menu);
        }else{
            inflater.inflate(R.menu.menu_options_activity_detail_2, menu);
        }
        return true;
    }

    /**
     * アクションバーが押された時の処理。
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int itemId = item.getItemId();
        switch (itemId) {
            case R.id.menuDetailUpdate:
                // 編集画面へ処理を移管する。
                Intent intent = new Intent(DetailActivity.this, UpdateActivity.class);
                intent.putExtra("idNo", _idNo);
                intent.putExtra("E_name", _event.get("E_name"));
                intent.putExtra("E_datetime", _event.get("E_datetime"));
                intent.putExtra("E_ticket_sum", _event.get("E_ticket_sum"));
                intent.putExtra("E_description", _event.get("E_description"));
                startActivity(intent);
                break;
            case R.id.menuDetailPublic:
                // 公開設定ダイアログ表示
                String urlPublic = getString(R.string.api_url) + "event/public";
                PublicDialogFragment dialog = new PublicDialogFragment(urlPublic, _idNo);
                FragmentManager manager = getSupportFragmentManager();
                dialog.show(manager, "PublicDialogFragment");
                break;
            case android.R.id.home:
                finish(); // 画面終了(イベント一覧画面に戻る)
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}
