package local.hal.st31.android.skpurchaser;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

public class TicketDetailActivity extends AppCompatActivity {
    /**
     * 現在表示している情報のデータベース上の値。
     */
    private String _eventId;
    private String _seatId;
    private String _eventName;
    private String _used_flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket_detail);

        // 前画面から情報を取得
        Intent intent = getIntent();
        _eventId = intent.getStringExtra("E_id");
        _seatId = intent.getStringExtra("T_seat_id");
        _eventName = intent.getStringExtra("E_name");
        String eventDatetime = intent.getStringExtra("E_datetime");
        String eventDescription = intent.getStringExtra("E_description");
        _used_flag = intent.getStringExtra("T_used_flag");

        ((TextView)findViewById(R.id.etDetailName)).setText(_eventName);
        ((TextView)findViewById(R.id.etDetailDatetime)).setText(eventDatetime);
        ((TextView)findViewById(R.id.etDetailDescription)).setText(eventDescription);

        // 使用済みチケットの場合ボタンを非活性
        if(_used_flag.equals("1")){
            Button btnDisplay = findViewById(R.id.btnDisplay);
            btnDisplay.setText(R.string.btn_disabled);
            btnDisplay.setEnabled(false);
        }

        // アクションバーに前画面に戻る機能をつける
        ActionBar actionBar = getSupportActionBar();
        Objects.requireNonNull(actionBar).setDisplayHomeAsUpEnabled(true);
    }

    /**
     * ボタンがクリックされた時の処理。
     * @param view 画面部品。
     */
    public void onDisplayButtonClick(View view){
        // QRコード表示画面へ処理を移管する。
        Intent intent = new Intent(TicketDetailActivity.this, QRDisplayActivity.class);
        intent.putExtra("E_id", _eventId);
        intent.putExtra("E_seatId", _seatId);
        intent.putExtra("E_name", _eventName);
        startActivity(intent);
    }

    /**
     * アクションバーが押された時の処理。
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int itemId = item.getItemId();
        switch (itemId) {
            case android.R.id.home:
                finish(); // 画面終了(mypage画面に戻る)
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}