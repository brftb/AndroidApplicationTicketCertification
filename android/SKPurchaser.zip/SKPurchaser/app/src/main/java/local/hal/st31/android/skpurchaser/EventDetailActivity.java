package local.hal.st31.android.skpurchaser;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class EventDetailActivity extends AppCompatActivity {
    /**
     * 現在表示している情報のデータベース上の主キー値。
     */
    private String _idNo;
    /**
     * get先のURL。
     */
    private static String GET_URL;
    /**
     * post先のURL。
     */
    private static String POST_URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);

        // set url
        GET_URL = getResources().getString(R.string.api_url) + "event/detail";
        POST_URL = getResources().getString(R.string.api_url) + "ticket/purchase";

        // ticketIdを取得
        Intent intent = getIntent();
        _idNo = intent.getStringExtra("idNo");

        // 送信パラメータと受信パラメータのセット
        String urlFull = GET_URL + "?event_id=" + _idNo;
        String[] keys = {"E_name", "E_datetime", "R_num", "E_description"};
        // 初期値の取得・表示
        GetTransfer getTransfer = new GetTransfer();
        Map<String, String> event = getTransfer.receiveMap(urlFull,"eventInfo", keys);
        ((TextView)findViewById(R.id.etDetailName)).setText(event.get("E_name"));
        ((TextView)findViewById(R.id.etDetailDatetime)).setText(event.get("E_datetime"));
        ((TextView)findViewById(R.id.etDetailNum)).setText(event.get("R_num"));
        ((TextView)findViewById(R.id.etDetailDescription)).setText(event.get("E_description"));

        // 売り切れの場合購入ボタンを非活性にする
        if(event.get("R_num").equals("0")){
            Button btnPurchase = findViewById(R.id.btnPurchase);
            btnPurchase.setText(R.string.btn_sold_out);
            btnPurchase.setEnabled(false);
        }

        // アクションバーに前画面に戻る機能をつける
        ActionBar actionBar = getSupportActionBar();
        Objects.requireNonNull(actionBar).setDisplayHomeAsUpEnabled(true);
    }

    /**
     * チケット購入ボタンがクリックされた時の処理。
     * @param view 画面部品。
     */
    public void onPurchaseButtonClick(View view){
        // mynumber取得
        DatabaseHelper helper = new DatabaseHelper(EventDetailActivity.this);
        SQLiteDatabase db = helper.getWritableDatabase();
        String mynumber = UserDao.findMynumber(db);
        // チケット購入処理。
        Map<String, String> keys = new HashMap<>();
        keys.put("event_id",_idNo);
        keys.put("mynumber",mynumber);
        // サーバーに送信
        PostTransfer post = new PostTransfer();
        if(post.sendPostDate(POST_URL, keys)){
            // ダイアログ表示
            PurchasedDialogFragment dialog = new PurchasedDialogFragment(getString(R.string.purchase_dlg_msg1));
            FragmentManager manager = getSupportFragmentManager();
            dialog.show(manager, "PurchasedDialogFragment");
        }else{
            // ダイアログ表示
            PurchasedDialogFragment dialog = new PurchasedDialogFragment(getString(R.string.purchase_dlg_msg2));
            FragmentManager manager = getSupportFragmentManager();
            dialog.show(manager, "PurchasedDialogFragment");
        }
    }

    /**
     * アクションバーが押された時の処理。
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int itemId = item.getItemId();
        switch (itemId) {
            case android.R.id.home:
                finish(); // 画面終了(イベント一覧画面に戻る)
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}