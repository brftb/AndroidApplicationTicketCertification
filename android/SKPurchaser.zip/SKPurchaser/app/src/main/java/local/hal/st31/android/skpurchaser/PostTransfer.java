package local.hal.st31.android.skpurchaser;

import android.util.Log;

import androidx.annotation.UiThread;
import androidx.annotation.WorkerThread;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class PostTransfer {
    /**
     * ログに記載するタグ用の文字列。
     */
    private static final String DEBUG_TAG = "SAMPLE";

    /**
     * コンストラクタ。
     */
    public PostTransfer(){
    }

    /**
     * 非同期でサーバにポストした後に取得したJSON文字列を解析し、TFで返す。
     *
     * @param accessUrl ポスト先URL。
     * @param keys ポストデータ郡。
     */
    @UiThread
    public Boolean sendPostDate(final String accessUrl, final Map<String, String> keys){
        BackgroundExecutor backgroundPostAccess = new BackgroundExecutor(accessUrl, keys);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<String> future = executorService.submit(backgroundPostAccess);
        String result = "";
        try{
            result = future.get();
        }catch (ExecutionException ex){
            Log.w(DEBUG_TAG, "非同期処理結果の取得で例外発生", ex);
        }catch (InterruptedException ex){
            Log.w(DEBUG_TAG, "非同期処理結果の取得で例外発生", ex);
        }
        String status = "";
        // JSON文字列から値の抽出
        try{
            JSONObject rootJSON = new JSONObject(result);
            status = rootJSON.getString("status");
        }catch (JSONException ex){
            Log.e(DEBUG_TAG, "JSON解析失敗", ex);
        }
        if(status.equals("1")) return true;
        else return false;
    }

    /**
     * 非同期でサーバにポストした後に取得したJSON文字列を解析し、UIスレッドで処理するためのクラス。
     *
     * @param accessUrl ポスト先URL。
     * @param keys ポストデータ郡。
     */
    @UiThread
    public String sendPostDateToGetResult(final String accessUrl, final Map<String, String> keys){
        BackgroundExecutor backgroundPostAccess = new BackgroundExecutor(accessUrl, keys);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<String> future = executorService.submit(backgroundPostAccess);
        String result = "";
        try{
            result = future.get();
        }catch (ExecutionException ex){
            Log.w(DEBUG_TAG, "非同期処理結果の取得で例外発生", ex);
        }catch (InterruptedException ex){
            Log.w(DEBUG_TAG, "非同期処理結果の取得で例外発生", ex);
        }
        String status = "";
        // JSON文字列から値の抽出
        try{
            JSONObject rootJSON = new JSONObject(result);
            status = rootJSON.getString("status");
        }catch (JSONException ex){
            Log.e(DEBUG_TAG, "JSON解析失敗", ex);
        }
        return status;
    }

    /**
     * 非同期でサーバにポストするためのクラス。
     */
    private class BackgroundExecutor implements Callable<String> {
        /**
         * ポスト先URL。
         */
        private final String _accessUrl;
        /**
         * ポストデータ郡。
         */
        private final Map<String, String> _keys;

        /**
         * コンストラクタ。
         */
        public BackgroundExecutor(String accessUrl, Map<String, String> keys){
            _accessUrl = accessUrl;
            _keys = keys;
        }

        @WorkerThread
        @Override
        public String call(){
            // 送信するデータをまとめる
            String postData = "";
            int i = 0;
            for(Map.Entry<String,String> entry : _keys.entrySet()){
                postData += entry.getKey() + "=" + entry.getValue();
                i++;
                if(i!=_keys.size()) postData += "&";
            }
            // 送信
            HttpURLConnection con = null;
            InputStream is = null;
            String result = "";
            boolean success = false;

            try{
                URL url = new URL(_accessUrl);
                con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setConnectTimeout(5000);
                con.setReadTimeout(5000);
                con.setDoOutput(true);

                OutputStream os = con.getOutputStream();
                os.write(postData.getBytes());
                os.flush();
                os.close();

                int status = con.getResponseCode();
                if(status != 200){
                    throw  new IOException("ステータスコード：" + status);
                }
                is = con.getInputStream();

                result = is2String(is);
                success = true;
            }catch (SocketTimeoutException ex){
                Log.e(DEBUG_TAG, "タイムアウト", ex);
            }catch (MalformedURLException ex){
                Log.e(DEBUG_TAG, "URL変換失敗", ex);
            }catch (IOException ex){
                Log.e(DEBUG_TAG, "通信失敗", ex);
            }finally {
                if(con != null){
                    con.disconnect();
                }
                if(is != null){
                    try{
                        is.close();
                    }catch (IOException ex){
                        Log.e(DEBUG_TAG, "InputStream解放失敗", ex);
                    }
                }
            }

            if(success) return result;
            else return null;
        }

        /**
         * InputStreamオブジェクトを文字列に変換するメソッド。
         * 変換文字コードはUTF-8。
         *
         * @param is 変換対象のInputStreamオブジェクト。
         * @return 変換されたJSON文字列。
         * @throws IOException 変換に失敗した時に発生。
         */
        private String is2String(InputStream is) throws IOException{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuffer sb = new StringBuffer();
            char[] b = new char[1024];
            int line;
            while (0 <= (line = reader.read(b))){
                sb.append(b, 0, line);
            }
            return sb.toString();
        }
    }
}
