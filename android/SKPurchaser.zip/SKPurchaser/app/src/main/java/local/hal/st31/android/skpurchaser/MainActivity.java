package local.hal.st31.android.skpurchaser;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.app.PendingIntent;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    /**
     * アダプタを扱うための変数。
     */
    private NfcAdapter mNfcAdapter;
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    /**
     * 選択されたuidの値を格納するフィールド。
     */
    private String _uid = "";
    /**
     * post先のURL。
     */
    private static String POST_URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // set url
        POST_URL = getResources().getString(R.string.api_url) + "user/main_check";

        _helper = new DatabaseHelper(MainActivity.this);
        SQLiteDatabase db = _helper.getWritableDatabase();

        // アカウント登録済ならMyPageに遷移
        if(UserDao.findRowByPK(db, 1)){
            Intent intent = new Intent(MainActivity.this, MyPageActivity.class);
            startActivity(intent);
            finish(); // 画面終了(破棄)
        }

        // 初動のダイアログ表示
        FirstDialogFragment dialog = new FirstDialogFragment();
        FragmentManager manager = getSupportFragmentManager();
        dialog.show(manager, "FirstDialogFragment");

        // アダプタのインスタンスを取得
        mNfcAdapter = android.nfc.NfcAdapter.getDefaultAdapter(this);

        // 参照ボタンの非活性化
        Button btnRead = findViewById(R.id.btnRead);
        btnRead.setEnabled(false);
    }

    @Override
    protected void onResume(){
        super.onResume();
        // NFCがかざされたときの設定
        Intent intent = new Intent(this, this.getClass());
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        // ほかのアプリを開かないようにする
        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0); // emulatorだとここでエラーなる
        mNfcAdapter.enableForegroundDispatch(this, pendingIntent, null, null);
    }

    @Override
    protected void onPause(){
        super.onPause();
        // Activityがバックグラウンドになったときは、受け取らない
        mNfcAdapter.disableForegroundDispatch(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // NFCのUIDを取得
        byte[] uid = intent.getByteArrayExtra(NfcAdapter.EXTRA_ID);
        // フィールドに格納
        _uid = Arrays.toString(uid);
        // 表示
        TextView tvMsg = findViewById(R.id.tvMsg);
        tvMsg.setText(tvMsg.getText().toString() + "\n" + _uid);

        // 登録済か確認
        Map<String, String> keys = new HashMap<>();
        keys.put("mynumber", _uid);
        PostTransfer postTransfer = new PostTransfer();
        String status = postTransfer.sendPostDateToGetResult(POST_URL, keys);
        if(status.equals("yes")){
            // 参照ボタンの活性化
            Button btnRead = findViewById(R.id.btnRead);
            btnRead.setEnabled(true);
        }else if(status.equals("no")){
            // ダイアログ
            Toast.makeText(MainActivity.this, R.string.msg_main_no, Toast.LENGTH_SHORT).show();
        }else{
            // ダイアログ
            Toast.makeText(MainActivity.this, R.string.msg_main_err, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 登録ボタンがクリックされたときの処理メソッド。
     *
     * @param view Viewオブジェクト。
     */
    public void onMainButtonClick(View view){
        // 画面遷移
        Intent intent = new Intent(MainActivity.this, RegisterInputActivity.class);
        intent.putExtra("readUid", _uid);
        startActivity(intent);
    }
}