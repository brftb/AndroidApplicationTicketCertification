package local.hal.st31.android.skpurchaser;

import java.util.List;
import java.util.Map;

public class ResListDto {
    private String _status;
    private List<Map<String, String>> _list;

    // setter & getter
    public String getStatus() {
        return _status;
    }
    public void setStatus(String status) {
        _status = status;
    }
    public List<Map<String, String>> getList() {
        return _list;
    }
    public void setList(List<Map<String, String>> list) {
        _list = list;
    }
}
