package local.hal.st31.android.skpurchaser;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.Map;

public class MyPageActivity extends AppCompatActivity {
    /**
     * データベースヘルパーオブジェクト。
     */
    private DatabaseHelper _helper;
    /**
     * get先のURL。
     */
    private static String GET_URL;
    /**
     * アカウントのマイナンバー。
     */
    private static String _mynumber;
    /**
     * リストビュー。
     */
    private ListView _lvPurchasedTicketsList;
    /**
     * リストビューに表示させるリストデータ。
     */
    private List<Map<String, String>> _list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_page);

        // set url
        GET_URL = getResources().getString(R.string.api_url) + "user/mypage";

        _helper = new DatabaseHelper(MyPageActivity.this);
        SQLiteDatabase db = _helper.getWritableDatabase();

        // mynumberを取得
        _mynumber = UserDao.findMynumber(db);

        // 名前表示
        String name = UserDao.findName(db);
        if(name.equals("")){
            // 登録し直し。
        }else {
            String title = "";
            if(name.length()<10) title = "「"+name+"」さんの所持チケット一覧";
            else if(name.length()<18) title = "「"+name+"」さんの\n所持チケット一覧";
            else title = "「"+name+"」さんの所持チケット一覧";
            ((TextView) findViewById(R.id.tvMyPageTitle)).setText(title);
        }

        // リストset
        _lvPurchasedTicketsList = findViewById(R.id.lvPurchasedTicketsList);
        _lvPurchasedTicketsList.setOnItemClickListener(new ListItemClickListener());
    }

    @Override
    protected void onResume(){
        super.onResume();
        // 送信パラメータと受信パラメータのセット
        String urlFull = GET_URL + "?mynumber=" + _mynumber;
        String[] keys = {"E_id", "E_name", "E_datetime", "E_description", "T_seat_id", "T_used_flag"};
        // リストの取得・表示
        String[] from = {"E_name", "E_datetime"};
        int[] to = {android.R.id.text1, android.R.id.text2};
        GetTransfer getTransfer = new GetTransfer();
        _list = getTransfer.receiveList(urlFull, keys);
        SimpleAdapter adapter = new SimpleAdapter(MyPageActivity.this, _list, android.R.layout.simple_list_item_2, from, to);
        _lvPurchasedTicketsList.setAdapter(adapter);
    }

    /**
     * リストがタップされた時の処理が記述されたリスナクラス。
     */
    private class ListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            // チケット詳細画面へ処理を移管する。
            Intent intent = new Intent(MyPageActivity.this, TicketDetailActivity.class);
            intent.putExtra("E_id", _list.get(position).get("E_id"));
            intent.putExtra("E_name", _list.get(position).get("E_name"));
            intent.putExtra("E_datetime", _list.get(position).get("E_datetime"));
            intent.putExtra("E_description", _list.get(position).get("E_description"));
            intent.putExtra("T_seat_id", _list.get(position).get("T_seat_id"));
            intent.putExtra("T_used_flag", _list.get(position).get("T_used_flag"));
            startActivity(intent);
        }
    }

    /**
     * 販売チケット一覧ボタンがクリックされた時の処理。
     * @param view 画面部品。
     */
    public void onMyPageButtonClick(View view){
        // チケット購入画面へ処理を移管する。
        Intent intent = new Intent(MyPageActivity.this, EventsListActivity.class);
        startActivity(intent);
    }
}