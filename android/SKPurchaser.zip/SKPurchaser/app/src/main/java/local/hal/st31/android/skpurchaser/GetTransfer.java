package local.hal.st31.android.skpurchaser;

import android.util.Log;

import androidx.annotation.UiThread;
import androidx.annotation.WorkerThread;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class GetTransfer {
    /**
     * ログに記載するタグ用の文字列。
     */
    private static final String DEBUG_TAG = "SAMPLE";

    /**
     * コンストラクタ。
     */
    public GetTransfer(){
    }

    /**
     * リストの取得処理を行うメソッド。
     * @param url 取得するURL。
     * @param keys JSON解析のためのKey郡。
     */
    @UiThread
    public ResListDto receiveList(final String url, String[] keys){
        InfoBackgroundReceiver backgroundReceiver = new InfoBackgroundReceiver(url);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<String> future = executorService.submit(backgroundReceiver);
        String result = "";
        try{
            result = future.get();
        }catch (ExecutionException ex){
            Log.w(DEBUG_TAG, "非同期処理結果の取得で例外発生", ex);
        }catch (InterruptedException ex){
            Log.w(DEBUG_TAG, "非同期処理結果の取得で例外発生", ex);
        }
        return getList(result, keys);
    }

    /**
     * 取得したJSON文字列を解析するメソッド。
     *
     * @param result 取得したJSON文字列。
     */
    @UiThread
    private ResListDto getList(String result, String[] keys){
        // リストを初期化する
        ResListDto dto = new ResListDto();
        List<Map<String, String>> list = new ArrayList<>();
        String status = getStatus(result);
        if("4".equals(status)){
            dto.setStatus("err");
        }else if("1".equals(status)){
            dto.setStatus("zero");
        }else {
            dto.setStatus("success");
            try {
                // listを取り出す
                JSONObject rootJSON = new JSONObject(result);
                JSONArray listJSON = rootJSON.getJSONArray("list");
                // listの中身を取り出す
                if (listJSON != null) {
                    for (int i = 0; i < listJSON.length(); i++) {
                        JSONObject recordJSON = listJSON.getJSONObject(i);
                        Map<String, String> map = new HashMap<>();
                        for (int j = 0; j < keys.length; j++) {
                            map.put(keys[j], recordJSON.getString(keys[j]));
                        }
                        list.add(map);
                    }
                }
            } catch (JSONException ex) {
                Log.e(DEBUG_TAG, "JSON解析失敗", ex);
            }
        }
        dto.setList(list);
        return dto;
    }

    /**
     * 一時的コードの取得処理を行うメソッド。
     * @param url 取得するURL。
     * @param key JSON解析のためのKey。
     */
    @UiThread
    public String receiveString(final String url, String key){
        InfoBackgroundReceiver backgroundReceiver = new InfoBackgroundReceiver(url);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<String> future = executorService.submit(backgroundReceiver);
        String result = "";
        try{
            result = future.get();
        }catch (ExecutionException ex){
            Log.w(DEBUG_TAG, "非同期処理結果の取得で例外発生", ex);
        }catch (InterruptedException ex){
            Log.w(DEBUG_TAG, "非同期処理結果の取得で例外発生", ex);
        }

        // 取得したJSON文字列を解析する
        String strResult = "";
        try{
            // listを取り出す
            JSONObject rootJSON = new JSONObject(result);
            strResult = rootJSON.getString(key);
        }catch (JSONException ex){
            Log.e(DEBUG_TAG, "JSON解析失敗", ex);
        }
        return strResult;
    }

    /**
     * 一時的コードの取得処理を行うメソッド。
     * @param url 取得するURL。
     * @param keys JSON解析のためのKey。
     */
    @UiThread
    public Map<String, String> receiveMap(final String url, String listName, String[] keys){
        InfoBackgroundReceiver backgroundReceiver = new InfoBackgroundReceiver(url);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<String> future = executorService.submit(backgroundReceiver);
        String result = "";
        try{
            result = future.get();
        }catch (ExecutionException ex){
            Log.w(DEBUG_TAG, "非同期処理結果の取得で例外発生", ex);
        }catch (InterruptedException ex){
            Log.w(DEBUG_TAG, "非同期処理結果の取得で例外発生", ex);
        }

        Map<String, String> map = new HashMap<>();
        // 取得したJSON文字列を解析する
        try{
            // listを取り出す
            JSONObject rootJSON = new JSONObject(result);
            JSONObject listJSON = rootJSON.getJSONObject(listName);
            // listの中身を取り出す
            if (listJSON != null) {
                for(int j=0; j<keys.length; j++){
                    map.put(keys[j], listJSON.getString(keys[j]));
                }
            }
        }catch (JSONException ex){
            Log.e(DEBUG_TAG, "JSON解析失敗", ex);
        }

        return map;
    }

    /**
     * 一時的コードの取得処理を行うメソッド。
     * @param result 取得したJSON文字列。
     */
    @UiThread
    public String getStatus(String result){
        String status = "";
        // 取得したJSON文字列を解析する
        try{
            JSONObject rootJSON = new JSONObject(result);
            status = rootJSON.getString("status");
        }catch (JSONException ex){
            Log.e(DEBUG_TAG, "JSON解析失敗", ex);
        }
        return status;
    }

    /**
     * 非同期でURLにアクセスするためのクラス。
     */
    public class InfoBackgroundReceiver implements Callable<String> {
        /**
         * 情報を取得するURL。
         */
        private final String _url;

        /**
         * コンストラクタ。
         *
         * @param url 情報を取得するURL。
         */
        public InfoBackgroundReceiver(String url){
            _url = url;
        }

        @WorkerThread
        @Override
        public String call(){
            HttpURLConnection con = null;
            InputStream is = null;
            String result = "";

            try{
                URL url = new URL(_url);
                con = (HttpURLConnection) url.openConnection();
                con.setConnectTimeout(500);
                con.setReadTimeout(500);
                con.setRequestMethod("GET");
                con.connect();
                int status = con.getResponseCode();
                if(status != 200){
                    // 擬似的に例外を発生させる
                    throw new IOException();
                }
                is = con.getInputStream();
                result = is2String(is);
            }catch (MalformedURLException ex){
                Log.e(DEBUG_TAG, "URL変換失敗", ex);
            }catch (SocketTimeoutException ex){
                Log.w(DEBUG_TAG, "通信タイムアウト", ex);
            }catch (IOException ex){
                Log.e(DEBUG_TAG, "通信失敗", ex);
            }finally {
                if(con != null){
                    con.disconnect();
                }
                if(is != null){
                    try{
                        is.close();
                    }catch (IOException ex){
                        Log.e(DEBUG_TAG, "InputStream解放失敗", ex);
                    }
                }
            }

            return result;
        }

        /**
         * InputStreamオブジェクトを文字列に変換するメソッド。
         * 変換文字コードはUTF-8。
         *
         * @param is 変換対象のInputStreamオブジェクト。
         * @return 変換された文字列。
         * @throws IOException 変換に失敗した時に発生。
         */
        private String is2String(InputStream is) throws IOException{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuffer sb = new StringBuffer();
            char[] b = new char[1024];
            int line;
            while (0 <= (line = reader.read(b))){
                sb.append(b, 0, line);
            }
            return sb.toString();
        }
    }

}
