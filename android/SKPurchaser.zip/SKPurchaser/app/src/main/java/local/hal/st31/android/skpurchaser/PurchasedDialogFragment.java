package local.hal.st31.android.skpurchaser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

public class PurchasedDialogFragment extends DialogFragment {
    /**
     * メッセージ。
     */
    private String _msg;

    /**
     * コンストラクタ。
     */
    public PurchasedDialogFragment(String msg){
        _msg = msg;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(_msg);
        builder.setPositiveButton(R.string.purchase_dlg_ok, new DialogButtonClickListener());
        AlertDialog dialog = builder.create();
        return dialog;
    }

    /**
     * ダイアログボタンが押された時の処理が記述されたメンバクラス。
     */
    private class DialogButtonClickListener implements DialogInterface.OnClickListener{
        @Override
        public void onClick(DialogInterface dialog, int which){
            Activity parent = getActivity();
            // EventsList画面ではなくMyPage画面に戻す
            Intent intent = new Intent(parent, MyPageActivity.class);
            // EventsListActivity と EventDetailActivity を消す
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            // MyPageActivity を再利用する（onCreate() は呼ばれない）
            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        }
    }
}
