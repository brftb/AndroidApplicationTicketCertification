package local.hal.st31.android.skpurchaser;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.util.AndroidRuntimeException;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.UiThread;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.util.Objects;

public class QRDisplayActivity extends AppCompatActivity {
    /**
     * get先のURL。
     */
    private static String GET_URL;
    /**
     * 現在表示している情報のデータベース上の値。
     */
    private String _eventId;
    private String _seatId;
    /**
     * アカウントのマイナンバー。
     */
    private static String _mynumber;
    /**
     * handler。
     */
    private final Handler _handler = new Handler();
    private Runnable _run;
    private Runnable _countDown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_display);

        // set url
        GET_URL = getResources().getString(R.string.api_url) + "qr/display";

        // 前画面から情報を取得
        Intent intent = getIntent();
        _eventId = intent.getStringExtra("E_id");
        _seatId = intent.getStringExtra("E_seatId");
        String eventName = intent.getStringExtra("E_name");

        ((TextView)findViewById(R.id.tvQrDisplaySubTitle)).setText(eventName);

        // mynumberを取得
        DatabaseHelper helper = new DatabaseHelper(QRDisplayActivity.this);
        SQLiteDatabase db = helper.getWritableDatabase();
        _mynumber = UserDao.findMynumber(db);

        //QRコード画像の大きさを指定(pixel)
        int size = 1000;

        // Handlerで定期実行
        _run = new Runnable() {
            @UiThread
            @Override
            public void run() {
                // 送信パラメータのセット
                String urlFull = GET_URL + "?eventId=" + _eventId + "&seatId=" + _seatId + "&mynumber=" + _mynumber;
                //QRコード化する文字列の取得
                GetTransfer getTransfer = new GetTransfer();
                String data = getTransfer.receiveString(urlFull, "code");

                try {
                    BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                    //QRコードをBitmapで作成
                    Bitmap bitmap = barcodeEncoder.encodeBitmap(data, BarcodeFormat.QR_CODE, size, size);

                    //作成したQRコードを画面上に配置
                    ImageView imageViewQrCode = (ImageView) findViewById(R.id.ivQr);
                    imageViewQrCode.setImageBitmap(bitmap);

                } catch (WriterException e) {
                    throw new AndroidRuntimeException("Barcode Error.", e);
                }

                _handler.postDelayed(this, 1000*21); // 20s+α(cnt=0も含む)
            }
        };
        _handler.post(_run);

        // Handlerで定期実行
        _countDown = new Runnable() {
            private int cnt = 21;
            @UiThread
            @Override
            public void run() {
                cnt --;
                if (cnt < 0) { // 20回実行したら終了
                    cnt = 20;
                }

                // プログレスバー更新
                ProgressBar pbCountDown = findViewById(R.id.pbCountDown);
                pbCountDown.setProgress(cnt);

                _handler.postDelayed(this, 1000); // 1s
            }
        };
        // プログレスバーで残り時間表示
        _handler.post(_countDown);

        // アクションバーに前画面に戻る機能をつける
        ActionBar actionBar = getSupportActionBar();
        Objects.requireNonNull(actionBar).setDisplayHomeAsUpEnabled(true);
    }

    /**
     * 端末の戻るボタンが押された時の処理。
     */
    @Override
    public void onBackPressed(){
        // 定期実行のキャンセル
        _handler.removeCallbacks(_run);
        _handler.removeCallbacks(_countDown);
        finish(); // 画面終了(MyPage画面に戻る)
    }

    /**
     * アクションバーが押された時の処理。
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int itemId = item.getItemId();
        switch (itemId) {
            case android.R.id.home:
                // 定期実行のキャンセル
                _handler.removeCallbacks(_run);
                _handler.removeCallbacks(_countDown);
                finish(); // 画面終了(MyPage画面に戻る)
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}