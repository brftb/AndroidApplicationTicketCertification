package local.hal.st31.android.skpurchaser;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.Map;
import java.util.Objects;

public class EventsListActivity extends AppCompatActivity {
    /**
     * get先のURL。
     */
    private static String GET_URL;
    /**
     * リストビュー。
     */
    private ListView _lvSalesTicketsList;
    /**
     * リストビューに表示させるリストデータ。
     */
    private List<Map<String, String>> _list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_list);

        // set url
        GET_URL = getResources().getString(R.string.api_url) + "event/list";

        // リストset
        _lvSalesTicketsList = findViewById(R.id.lvSalesTicketsList);
        _lvSalesTicketsList.setOnItemClickListener(new ListItemClickListener());

        // アクションバーに前画面に戻る機能をつける
        ActionBar actionBar = getSupportActionBar();
        Objects.requireNonNull(actionBar).setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected void onResume(){
        super.onResume();
        // リストの取得・表示
        String[] from = {"E_name"};
        int[] to = {android.R.id.text1, android.R.id.text2};
        GetTransfer getTransfer = new GetTransfer();
        String[] keys = {"E_id", "E_name"};
        ResListDto dto = getTransfer.receiveList(GET_URL, keys);
        if(dto.getStatus().equals("err")){
            ((TextView)findViewById(R.id.tvEventList)).setText(R.string.tv_events_list_err);
        }else if(dto.getStatus().equals("zero")){
            ((TextView)findViewById(R.id.tvEventList)).setText(R.string.tv_events_list_zero);
        }else if(dto.getStatus().equals("success")) {
            _list = dto.getList();
            SimpleAdapter adapter = new SimpleAdapter(EventsListActivity.this, _list, android.R.layout.simple_list_item_1, from, to);
            _lvSalesTicketsList.setAdapter(adapter);
        }
    }

    /**
     * リストがタップされた時の処理が記述されたリスナクラス。
     */
    private class ListItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            // チケット詳細画面へ処理を移管する。
            Intent intent = new Intent(EventsListActivity.this, EventDetailActivity.class);
            intent.putExtra("idNo", _list.get(position).get("E_id"));
            startActivity(intent);
        }
    }

    /**
     * アクションバーが押された時の処理。
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int itemId = item.getItemId();
        switch (itemId) {
            case android.R.id.home:
                finish(); // 画面終了(MyPage画面に戻る)
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}