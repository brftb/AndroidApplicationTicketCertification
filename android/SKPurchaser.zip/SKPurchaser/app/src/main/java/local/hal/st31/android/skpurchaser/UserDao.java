package local.hal.st31.android.skpurchaser;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

public class UserDao {
    /**
     * 主キーによるレコード存在チェックメソッド。
     *
     * @param db SQLiteDatabaseオブジェクト。
     * @param id 主キー値。
     * @return 主キーに対応するレコードが存在するかどうかを表すBool値。存在する場合はtrue、存在しない場合はfalse。
     */
    public static boolean findRowByPK(SQLiteDatabase db, int id){
        String sql = "SELECT COUNT(*) AS count FROM user WHERE _id = " + id;
        Cursor cursor = db.rawQuery(sql, null);
        boolean result = false;
        if(cursor.moveToFirst()){
            int idxCount = cursor.getColumnIndex("count");
            int count = cursor.getInt(idxCount);
            if(count >= 1){
                result = true;
            }
        }
        return result;
    }

    /**
     * 主キーによる検索メソッド。
     *
     * @param db SQLiteDatabaseオブジェクト。
     * @return Name。
     */
    public static String findName(SQLiteDatabase db){
        String sql = "SELECT name FROM user WHERE _id = 1";
        Cursor cursor = db.rawQuery(sql, null);
        String result = "";
        if(cursor.moveToFirst()){
            int idxName = cursor.getColumnIndex("name");
            String name = cursor.getString(idxName);
            result = name;
        }
        return result;
    }
    public static String findMynumber(SQLiteDatabase db){
        String sql = "SELECT mynumber FROM user WHERE _id = 1";
        Cursor cursor = db.rawQuery(sql, null);
        String result = "";
        if(cursor.moveToFirst()){
            int idxMynumber = cursor.getColumnIndex("mynumber");
            String mynumber = cursor.getString(idxMynumber);
            result = mynumber;
        }
        return result;
    }

    /**
     * 情報を新規登録するメソッド。
     *
     * @param db SQLiteDatabaseオブジェクト。
     * @param name 名。
     * @return 登録したレコードの主キー値。
     */
    public static long insert(SQLiteDatabase db, String mynumber, String name){
        String sql = "INSERT INTO user (mynumber, name) VALUES(?,?)";
        SQLiteStatement stmt = db.compileStatement(sql);
        stmt.bindString(1, mynumber);
        stmt.bindString(2, name);
        long insertedId = stmt.executeInsert();
        return insertedId;
    }
}
