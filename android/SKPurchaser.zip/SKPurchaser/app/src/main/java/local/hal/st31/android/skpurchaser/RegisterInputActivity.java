package local.hal.st31.android.skpurchaser;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

public class RegisterInputActivity extends AppCompatActivity {
    /**
     * 選択されたuidの値を格納するフィールド。
     */
    private String _uid;
    /**
     * post先のURL。
     */
    private static String POST_URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_input);

        // set url
        POST_URL = getResources().getString(R.string.api_url) + "user/register";

        // intentからuidを取得する。
        Intent intent = getIntent();
        _uid = intent.getStringExtra("readUid");
    }

    /**
     * ボタンがクリックされたときの処理メソッド。
     *
     * @param view Viewオブジェクト。
     */
    public void onRegisterButtonClick(View view){
        // 入力情報の取得
        EditText etInputName = findViewById(R.id.etInputName);
        String inputName = etInputName.getText().toString();
        String inputPassword = ((EditText)findViewById(R.id.etInputPassword)).getText().toString();
        String inputMail = ((EditText)findViewById(R.id.etInputMail)).getText().toString();
        // 必須入力の確認
        if (inputName.equals("")) {
            Toast.makeText(RegisterInputActivity.this, R.string.msg_input_name, Toast.LENGTH_SHORT).show();
        }else if (inputPassword.equals("")) {
            Toast.makeText(RegisterInputActivity.this, R.string.msg_input_password, Toast.LENGTH_SHORT).show();
        }else if (inputMail.equals("")) {
            Toast.makeText(RegisterInputActivity.this, R.string.msg_input_mail, Toast.LENGTH_SHORT).show();
        } else {
            // 登録のダイアログ表示
            RegisterDialogFragment dialog = new RegisterDialogFragment(POST_URL, _uid, inputName, inputPassword, inputMail);
            FragmentManager manager = getSupportFragmentManager();
            dialog.show(manager, "RegisterDialogFragment");
        }
    }
}